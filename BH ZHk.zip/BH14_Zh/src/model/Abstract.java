/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Objects;

/**
 *
 * @author ricsi
 */
public abstract class Abstract {
    private String ID;
    private static int airPlaneNumber = 0;
    private static int bmwNumber = 0;
    
    public Abstract() {
        if (this instanceof AirPlane){
            airPlaneNumber++;
            this.ID = getClass().getSimpleName()+"0000"+airPlaneNumber;
        }else if (this instanceof BMW){
            bmwNumber++;
            this.ID = getClass().getSimpleName()+"0000"+bmwNumber ;
        } else{
            System.out.println("Ismeretlen tipus!");
        }
    }
    public int getRandom(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
    
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.ID);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Abstract other = (Abstract) obj;
        if (!Objects.equals(this.ID, other.ID)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        //1. AirPlane created with #ID
        return super.getClass().getSimpleName() + ", ID=" + ID + '}';
    }
    
}
