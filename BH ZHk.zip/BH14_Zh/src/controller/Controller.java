/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.AirPlane;
import model.BMW;
import model.Model;
import view.View;

/**
 *
 * @author ricsi
 */
public class Controller {
    private Model model;

    public Controller(Model model) {
        this.model = model;
        start();
    }

    private void start() {
        View view = new View(this);
    }
    
    public void addBmw(){
        model.addList(new BMW());
    }
    
    public String addAirPlane(){
        AirPlane tmp = new AirPlane();
        model.addList(tmp);
        return tmp.toString();
    }
    
}
