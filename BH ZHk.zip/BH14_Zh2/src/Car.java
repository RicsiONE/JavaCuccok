/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ricsi
 */
public class Car extends Vehicle {

    private int numberOfDoors;
    private boolean carIsVan;

    public Car(String ID, int age, int weight) {
        super(ID, age, weight);
        upEmplyVarriable();
    }

    public void upEmplyVarriable(){
        if (super.getBoolean()){
            this.carIsVan = true;
            this.numberOfDoors = 3;
        } else {
            this.carIsVan = false;
            this.numberOfDoors = super.getRandom(1, 5);
            
        }
    }
    public Car(int numberOfDoors, boolean carIsVan, String ID, int age, int weight) {
        super(ID, age, weight);
        this.numberOfDoors = numberOfDoors;
        this.carIsVan = carIsVan;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    public boolean isCarIsVan() {
        return carIsVan;
    }

    public void setCarIsVan(boolean carIsVan) {
        this.carIsVan = carIsVan;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + this.numberOfDoors;
        hash = 59 * hash + (this.carIsVan ? 1 : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Car other = (Car) obj;
        if (this.numberOfDoors != other.numberOfDoors) {
            return false;
        }
        if (this.carIsVan != other.carIsVan) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Car{" + "numberOfDoors=" + numberOfDoors + ", carIsVan=" + carIsVan + super.rString() + '}';
    }

    @Override
    public boolean fly() {
        return false;
    }

    @Override
    public boolean drive() {
        return true;
    }

    @Override
    public boolean move() {
        return true;
    }
}
