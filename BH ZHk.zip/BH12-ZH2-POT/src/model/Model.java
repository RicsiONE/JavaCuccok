/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 *
 * @author ricsi
 */
public class Model {
    private final int MINMIDORIAN = 100;
    private final int MAXMIDORIAN = 20000;
    public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss"; 
    private Map<String, Integer> jediNameNumber = new HashMap();
    private Map<String, Integer> sithNameNumber = new HashMap();
    String[] jediName = {"Teor", "Mur", "Tata", "Kun", "Hun"};
    String[] sithName = {"Dark", "BB", "Ran", "Lee", "Gru"};
    private int sithCount = 0;
    List<AbstractWarriors> warriorsList = new ArrayList();
    
 
    public static String getNowTime() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
        return sdf.format(cal.getTime());
    }
    
    public String addJedi(){
        sithCount = 0;
        Jedi temp;
        temp = new Jedi(getRandomJediName(), getRandom(MINMIDORIAN, MAXMIDORIAN));
        warriorsList.add(temp);
        String retunString = String.format("%s neve: %s létrehozva ekkor: %s",temp.getClass().getSimpleName(), temp.getName(), getNowTime());
        return retunString;
    }
    
    public String addSith(){
        if (sithCount >= 2){
            //return "Nem tudsz ketőnél több Shitet hozzáadni!";
            throw new IllegalArgumentException("Nem tudsz ketőnél több Sithet hozzáadni egymás után!");
        }
        sithCount++;
        Sith temp;
        temp = new Sith(getRandomShitName(), getRandom(MINMIDORIAN, MAXMIDORIAN));
        warriorsList.add(temp);
        String retunString = String.format("%s neve: %s létrehozva ekkor: %s",temp.getClass().getSimpleName(), temp.getName(), getNowTime());
        return retunString;
    }
    
    public int getRandom(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
    
    public String getRandomJediName(){
        String temp = jediName[getRandom(0, jediName.length)];
        
        if (jediNameNumber.containsKey(temp)){
            jediNameNumber.replace(temp, (jediNameNumber.get(temp)+1));
            temp += jediNameNumber.get(temp);
        } else {
            jediNameNumber.put(temp, 1);
        }
        
        return temp;
    }

    public String getRandomShitName(){
        String temp = sithName[getRandom(0, sithName.length)];
        
        if (sithNameNumber.containsKey(temp)){
            sithNameNumber.replace(temp, (sithNameNumber.get(temp)+1));
            temp += sithNameNumber.get(temp);
        } else {
            sithNameNumber.put(temp, 1);
        }
        return temp;
    }

    public boolean saveFile(){
        File f = new File("fight.txt");
        int jediAllMedirian = 0;
        int sithAllMedirian = 0;
        boolean saveSuccessfully = false;
        
        try (PrintWriter out = new PrintWriter(f)) {
            if (warriorsList.isEmpty()){
                out.println("Senki nem nyert :) Nincs még hozzáadva Harcos!");
                out.println("Kattints a \"Jedi hozzáadása\" vagy \"Sith hozzáadása\" gombra egy harcos felvételéhez!");
            } else{
                for (AbstractWarriors abstractWarriors : warriorsList) {
                    out.println(abstractWarriors);
                    if (abstractWarriors instanceof Jedi){
                        jediAllMedirian += abstractWarriors.getMidiklorian();
                    }else {
                        sithAllMedirian += abstractWarriors.getMidiklorian();
                    }
                }
                int tmp = (sithAllMedirian*10);
                if (jediAllMedirian > tmp){
                    out.println("");
                    out.println("Jedik nyertek");
                    out.println("-----------------------");
                    out.println("Jedinek "+jediAllMedirian +" medoriánjuk volt a Sihteknek " +(jediAllMedirian-tmp) +" kellet volna a gyözelemhez");
                }else {
                    out.println("");
                    out.println("Sithek nyertek");
                    out.println("-----------------------");
                    out.println("Jediknek "+tmp +" medorián kellet volna a gyözelemhez, helyete csak "+jediAllMedirian +" volt."); 
                } 
            }
            saveSuccessfully = true; 
        } catch (Exception ex) {
            //ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
        return saveSuccessfully;
    }
    
    
}