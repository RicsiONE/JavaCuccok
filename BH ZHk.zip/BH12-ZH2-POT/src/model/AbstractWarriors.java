/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Objects;

/**
 *
 * @author ricsi
 */
public class AbstractWarriors {
    private String name;
    private int midiklorian;

    public AbstractWarriors(String name, int midiklorian) {
        this.name = name;
        this.midiklorian = midiklorian;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMidiklorian() {
        return midiklorian;
    }

    public void setMidiklorian(int midiklorian) {
        this.midiklorian = midiklorian;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.name);
        hash = 79 * hash + this.midiklorian;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AbstractWarriors other = (AbstractWarriors) obj;
        if (this.midiklorian != other.midiklorian) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return super.getClass().getSimpleName().toString()+" neve: " + name + ", midikloriánja: " + midiklorian;
    }
    
    
}
