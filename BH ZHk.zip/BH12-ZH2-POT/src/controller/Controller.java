/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Model;
import view.View;

/**
 *
 * @author ricsi
 */
public class Controller {
    private Model model;
    private View view;
    
    public Controller(Model model) {
        this.model = model;
        start();
    }

    private void start() {
        this.view = new View(this);
    }
    
    public String addJedi(){
        return model.addJedi();
    }
    
    public String addSith(){
        String temp = "";
        try {
            temp = model.addSith();
        }catch (IllegalArgumentException e){
            temp = e.getMessage();
        }
        return temp;
    }
    
    public String fight(){
        if (model.saveFile()){
            return "Sikeres mentés!";
        }else{
            return "Hoppá mentés során valami gond volt!";
        }
    }
}
