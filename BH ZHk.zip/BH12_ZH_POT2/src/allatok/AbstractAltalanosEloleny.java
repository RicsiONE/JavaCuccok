/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author ricsi
 */
public abstract class AbstractAltalanosEloleny implements Comparable<AbstractAltalanosEloleny>{
    private String fajtaja;
    private String szuletesiDatum;
    private double tomeg;

    public AbstractAltalanosEloleny(String fajtaja, String szuletesiDatum, double tomeg) {
        this.fajtaja = fajtaja;
        this.szuletesiDatum = szuletesiDatum;
        this.tomeg = tomeg;
    }
    abstract Eloleny foOsellenseg();
    
    public String getFajtaja() {
        return fajtaja;
    }

    public void setFajtaja(String fajtaja) {
        this.fajtaja = fajtaja;
    }

    public String getSzuletesiDatum() {
        return szuletesiDatum;
    }

    public void setSzuletesiDatum(String szuletesiDatum) {
        this.szuletesiDatum = szuletesiDatum;
    }

    public double getTomeg() {
        return tomeg;
    }
    public int getTomegInt() {
        return (int)tomeg;
    }

    public void setTomeg(double tomeg) {
        this.tomeg = tomeg;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + Objects.hashCode(this.fajtaja);
        hash = 37 * hash + Objects.hashCode(this.szuletesiDatum);
        hash = 37 * hash + (int) (Double.doubleToLongBits(this.tomeg) ^ (Double.doubleToLongBits(this.tomeg) >>> 32));
        return hash;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AbstractAltalanosEloleny other = (AbstractAltalanosEloleny) obj;
        if (this.tomeg != other.tomeg) {
            return false;
        }
        if (!Objects.equals(this.fajtaja, other.fajtaja)) {
            return false;
        }
        if (!Objects.equals(this.szuletesiDatum, other.szuletesiDatum)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return super.getClass().getSimpleName() +" fajtaja: " + fajtaja + ", születési dátuma: " + szuletesiDatum + ", tömege: " + String.format("%.2f", tomeg)+" kg";
    }

    @Override
    public int compareTo(AbstractAltalanosEloleny o) {
        return  this.getTomegInt() - o.getTomegInt();
    }

    
}
