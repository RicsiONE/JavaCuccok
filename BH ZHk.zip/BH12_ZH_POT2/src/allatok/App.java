/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author ricsi
 */
public class App {
    public static List<AbstractAltalanosEloleny> elolenyLista = new ArrayList();
    public static String[] kutyaNevek = {"Rex", "Cézár", "Harcos"};
    public static String[] macskaNevek = {"Lusta", "Romboló", "Haszontalan"};
    public static String[] egerNevek = {"Cincin", "Sajtmániás", "Blöffi"};
    
    public static void main(String[] args) {
        elolenyListaFeltoltese();
        elolenyListaNovekvoSorbaRendezese();
        riportok();
        
    }

    private static void elolenyListaFeltoltese() {
        for (int i = 0; i <= 100; i++) {
            if (i<=20){
                elolenyLista.add(new Kutya(veletlenKutyaFajta(), veletlenSzuletesiDatum(), veletlenKutyaTomeg()));
            } else if (i<=50){
                elolenyLista.add(new Macska(veletlenMacsakaFajta(), veletlenSzuletesiDatum(), veletlenMacskaTomeg()));
            }else{
                elolenyLista.add(new Eger(veletlenEgerFajta(), veletlenSzuletesiDatum(), veletlenEgerTomeg()));
            }
        }
    }
    public static int getRandom(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
    public static double getRandomDouble(int min, int max){
        return ((Math.random() * (max - min)) + min);
    }
    public static String veletlenKutyaFajta(){
        return kutyaNevek[getRandom(0, kutyaNevek.length)];
    }
    public static String veletlenMacsakaFajta(){
        return macskaNevek[getRandom(0, macskaNevek.length)];
    }
    public static String veletlenEgerFajta(){
        return egerNevek[getRandom(0, egerNevek.length)];
    }
    public static String veletlenSzuletesiDatum(){
        StringBuilder tmp = new StringBuilder();
        tmp.append(getRandom(2000, 2020));
        tmp.append("-");
        tmp.append(getRandom(1, 12));
        tmp.append("-");
        tmp.append(getRandom(1, 28));
        return tmp.toString();
    }
    
    public static double veletlenEgerTomeg(){
        return getRandomDouble(0, 1);
    }
    public static double veletlenKutyaTomeg(){
        return getRandomDouble(3, 40);
    }
    public static double veletlenMacskaTomeg(){
        return getRandomDouble(1, 5);
    }

    private static void elolenyListaNovekvoSorbaRendezese() {
        System.out.println("Lista rendezés elött:");
        System.out.println("---------------------");
        System.out.println(elolenyLista);
        System.out.println("");
        System.out.println("---------------------");
        System.out.println("Rendezés után:");
        System.out.println("---------------------");
        Collections.sort(elolenyLista);
        System.out.println(elolenyLista);
        System.out.println("");

    }

    private static void riportok() {
        System.out.println("Legidősebb élölény: " +legidosebbEloleny());
        System.out.println("Legfiatalabb macska: "+legfiatalabbMacsaka());
        System.out.println("Egerek ösztömege: "+egerekOsztomege()+" kg");
    }

    private static String legidosebbEloleny() {
       String tmp;
        String levagott;
        int tmpEvszam = 0;
        AbstractAltalanosEloleny legidosebbEloleny = null;
        int legidosebbElolenyKora = Integer.MAX_VALUE;
        for (AbstractAltalanosEloleny eloleny : elolenyLista) {
            tmp = eloleny.getSzuletesiDatum(); // 2019-1-25
            levagott = tmp.substring(0, 4);
            tmpEvszam = Integer.parseInt(levagott);
            if (tmpEvszam < legidosebbElolenyKora){
                legidosebbElolenyKora = tmpEvszam;
                legidosebbEloleny = eloleny;
            }
        }
        if (legidosebbEloleny == null){
            return "Nincsek a listában élölények";
        }else{
            return legidosebbEloleny.toString();
        }
    }

    private static String legfiatalabbMacsaka() {
        int legfiatalabb = Integer.MIN_VALUE;
        String tmp;
        String levagott;
        int tmpEvszam = 0;
        AbstractAltalanosEloleny legidosebbEloleny = null;
        for (AbstractAltalanosEloleny eloleny : elolenyLista) {
            if (eloleny instanceof Macska){
                tmp = eloleny.getSzuletesiDatum(); // 2019-1-25
                levagott = tmp.substring(0, 4);
                tmpEvszam = Integer.parseInt(levagott);
                if (tmpEvszam > legfiatalabb){
                    legfiatalabb = tmpEvszam;
                    legidosebbEloleny = eloleny;
                }
            }
        }
        if (legidosebbEloleny == null){
            return "Nincs macsaka a listába";
        }else{
            return legidosebbEloleny.toString();
        }
    }

    private static String egerekOsztomege() {
        double egerekOsztomege = 0;
        for (AbstractAltalanosEloleny eloleny : elolenyLista) {
            if (eloleny instanceof Eger){
                egerekOsztomege += eloleny.getTomeg();
            }
        }
        
        return String.format("%.2f", egerekOsztomege);
    }
    
}
