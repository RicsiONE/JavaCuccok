/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Spike implements Eloleny{
    private boolean vanSegecsesNyakovam = true;

    public boolean isVanSegecsesNyakovam() {
        return vanSegecsesNyakovam;
    }
    
    
    public void elTudomKapniTomotEsJerrytis(){
        System.out.println("Elkaptam Tomot és Jerryt!");
    }
    @Override
    public void leiras() {
        System.out.println("Ház környékbéli kutya. Nagy, erős, szürke színű felnőtt bulldog. Gyakran Jerry oldalán állva megleckézteti Tom-ot.");
    }

    

    
}
