/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Kutya extends AbstractAltalanosEloleny implements Koszones{
    private EnumKutyaCelja kutyakCelja;
    
    public Kutya(String fajtaja, String szuletesiDatum, double tomeg) {
        super(fajtaja, szuletesiDatum, tomeg);
        this.kutyakCelja = EnumKutyaCelja.SZOBA;
    }

    public EnumKutyaCelja getKutyakCelja() {
        return kutyakCelja;
    }

    public void setKutyakCelja(EnumKutyaCelja kutyakCelja) {
        this.kutyakCelja = kutyakCelja;
    }

    
    @Override
    Eloleny foOsellenseg() {
        return new Tom();
    }

    @Override
    public void seyHello() {
        System.out.println("SayHello"); //To change body of generated methods, choose Tools | Templates.
    }
    
}
