/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Tom implements Eloleny{

    @Override
    public void leiras() {
        System.out.println("Élete lustálkodásból és egérfogdosásból (Ritkán sikerül neki)  áll. Nagyon szeret enni.Mindenféle dolgot kieszel, hogy elkapja Jerryt. Néha durva eszközöket is alkalmaz. Testszíne szürke, kék, és fehér.");
    }
    
}
