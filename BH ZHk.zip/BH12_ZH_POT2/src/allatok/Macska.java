/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Macska extends AbstractAltalanosEloleny implements Koszones{
    
    public Macska(String fajtaja, String szuletesiDatum, double tomeg) {
        super(fajtaja, szuletesiDatum, tomeg);
    }

    @Override
    Eloleny foOsellenseg() {
       return new Jerry();
    }

    @Override
    public void seyHello() {
        System.out.println("SayHello");
    }
    
}
