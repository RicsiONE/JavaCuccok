/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Jerry implements Eloleny{
    private String szinem = "Barna vagyok";

    public String getSzinem() {
        return szinem;
    }
    
    
    public void megtudomUtniTomot(){
        System.out.println("Tom buff");
    }
    @Override
    public void leiras() {
        System.out.println("Pöttöm barna egér. Rendkívül kedves, okos, ravasz és sármos. Gyakran védi meg a többi ház körüli élőlényt Tom elől. A legtöbbször túljár Tom eszén.");
    }
    
}
