/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allatok;

/**
 *
 * @author ricsi
 */
public class Eger extends AbstractAltalanosEloleny{

    public Eger(String fajtaja, String szuletesiDatum, double tomeg) {
        super(fajtaja, szuletesiDatum, tomeg);
    }

    @Override
    Eloleny foOsellenseg() {
        return new Tom();
    }
    
    public void elbujtamAFoldAla(){
        System.out.println("Elbujtam a föld alá mert képes vagyok rá.....");
    }
    

    
    
}
