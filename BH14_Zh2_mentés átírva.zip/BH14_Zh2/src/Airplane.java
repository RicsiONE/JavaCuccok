/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ricsi
 */
public class Airplane extends Vehicle{
    private boolean readyToFly;
    private int flightAltitude; 

    public Airplane(String ID, int age, int weight) {
        super(ID, age, weight);
        upEmplyVarriable();
    }

    public Airplane(boolean readyToFly, int flightAltitude, String ID, int age, int weight) {
        super(ID, age, weight);
        this.readyToFly = readyToFly;
        this.flightAltitude = flightAltitude;
    }
    
    public void upEmplyVarriable(){
        this.readyToFly = super.getBoolean();
        this.flightAltitude = super.getRandom(500, 3500);
    }
            
    public boolean isReadyToFly() {
        return readyToFly;
    }

    public void setReadyToFly(boolean readyToFly) {
        this.readyToFly = readyToFly;
    }

    public int getFlightAltitude() {
        return flightAltitude;
    }

    public void setFlightAltitude(int flightAltitude) {
        this.flightAltitude = flightAltitude;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + (this.readyToFly ? 1 : 0);
        hash = 79 * hash + this.flightAltitude;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Airplane other = (Airplane) obj;
        if (this.readyToFly != other.readyToFly) {
            return false;
        }
        if (this.flightAltitude != other.flightAltitude) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Airplane{" + "readyToFly=" + readyToFly + ", flightAltitude=" + flightAltitude + super.rString() + '}';
    }

    
    
    
    @Override
    public boolean fly() {
        return true;
    }

    @Override
    public boolean drive() {
        return true;
    }

    @Override
    public boolean move() {
        return true;
    }
}
