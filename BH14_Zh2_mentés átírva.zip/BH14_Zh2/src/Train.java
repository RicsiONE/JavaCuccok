



import java.util.Arrays;
import java.util.Objects;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ricsi
 */
public class Train extends Vehicle{
    private boolean freightTrain; 
    private int howManyWagonsYouCanTow;
    private Enum_Train speed;

    public Train(String ID, int age, int weight) {
        super(ID, age, weight);
        upEmplyVarriable();
    }

    public Train(boolean freightTrain, int howManyWagonsYouCanTow, Enum_Train speed, String ID, int age, int weight) {
        super(ID, age, weight);
        this.freightTrain = freightTrain;
        this.howManyWagonsYouCanTow = howManyWagonsYouCanTow;
        this.speed = speed;
    }

    public void upEmplyVarriable(){
        this.freightTrain = super.getBoolean();
        this.howManyWagonsYouCanTow = super.getRandom(10, 100);
        this.speed = getEnumTrain();
    }
    
    public Enum_Train getEnumTrain(){
        Enum_Train[] enumTrainArray = Enum_Train.values();
        return enumTrainArray[super.getRandom(0, enumTrainArray.length)];
    }
    public boolean isFreightTrain() {
        return freightTrain;
    }

    public void setFreightTrain(boolean freightTrain) {
        this.freightTrain = freightTrain;
    }

    public int getHowManyWagonsYouCanTow() {
        return howManyWagonsYouCanTow;
    }

    public void setHowManyWagonsYouCanTow(int howManyWagonsYouCanTow) {
        this.howManyWagonsYouCanTow = howManyWagonsYouCanTow;
    }

    public Enum_Train getSpeed() {
        return speed;
    }

    public void setSpeed(Enum_Train speed) {
        this.speed = speed;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 11 * hash + (this.freightTrain ? 1 : 0);
        hash = 11 * hash + this.howManyWagonsYouCanTow;
        hash = 11 * hash + Objects.hashCode(this.speed);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Train other = (Train) obj;
        if (this.freightTrain != other.freightTrain) {
            return false;
        }
        if (this.howManyWagonsYouCanTow != other.howManyWagonsYouCanTow) {
            return false;
        }
        if (this.speed != other.speed) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Train{" + "freightTrain=" + freightTrain + ", howManyWagonsYouCanTow=" + howManyWagonsYouCanTow + ", speed=" + speed + super.rString() + '}';
    }

    
    @Override
    public boolean fly() {
        return false;
    }

    @Override
    public boolean drive() {
        return true;
    }

    @Override
    public boolean move() {
        return true;
    }
}
