
import java.util.Objects;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ricsi
 */
public abstract class Vehicle implements Comparable<Vehicle>{
    private String ID;
    private int age;
    private int weight;

    public Vehicle(String ID, int age, int weight) {
        this.ID = ID;
        this.age = age;
        this.weight = weight;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.ID);
        hash = 59 * hash + Objects.hashCode(this.age);
        hash = 59 * hash + this.weight;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vehicle other = (Vehicle) obj;
        if (this.weight != other.weight) {
            return false;
        }
        if (!Objects.equals(this.ID, other.ID)) {
            return false;
        }
        if (!Objects.equals(this.age, other.age)) {
            return false;
        }
        return true;
    }
    public String rString(){
        return ", ID=" + ID + ", age=" + age + ", weight=" + weight;
    }
    @Override
    public String toString() {
        return super.getClass().getSimpleName() + " ID=" + ID + ", age=" + age + ", weight=" + weight;
    }
    
    public int getRandom(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
    
    public boolean getBoolean(){
        if (((int) ((Math.random() * (1 - 0)) + 0)) == 1){
            return true;
        } else {
            return false;
        }
    }
    
    public abstract boolean fly();
    public abstract boolean drive();
    public abstract boolean move();

    @Override
    public int compareTo(Vehicle o) {
        return  this.getAge() - o.getAge();
    }
}
